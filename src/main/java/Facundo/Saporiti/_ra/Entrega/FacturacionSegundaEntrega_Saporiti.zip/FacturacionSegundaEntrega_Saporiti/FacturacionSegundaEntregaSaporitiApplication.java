package Facundo.Saporiti._ra.Entrega.FacturacionSegundaEntrega_Saporiti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacturacionSegundaEntregaSaporitiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FacturacionSegundaEntregaSaporitiApplication.class, args);
	}

}
