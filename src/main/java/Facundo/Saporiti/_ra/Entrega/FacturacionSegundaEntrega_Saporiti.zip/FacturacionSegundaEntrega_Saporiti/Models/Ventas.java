package Facundo.Saporiti._ra.Entrega.FacturacionSegundaEntrega_Saporiti.Models;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Entity
@Table (name = "VENTA")

public class Ventas {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column (name = "NOMBREPRODUCTO")
    private String nombreProducto;

    @Column (name = "COMPROBANTE")
    private Date fecha;

    @Column (name = "TOTALVENTA")
    private BigDecimal precio;

    @OneToMany (mappedBy = "venta", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Ventas_Productos> ventasProductos;

    public Ventas() {
    }

    public Ventas(String nombreProducto, Date fecha, BigDecimal precio) {
        this.nombreProducto = nombreProducto;
        this.fecha = fecha;
        this.precio = precio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public List<Ventas_Productos> getVentasProductos() {
        return ventasProductos;
    }

    public void setVentasProductos(List<Ventas_Productos> ventasProductos) {
        this.ventasProductos = ventasProductos;
    }

    public BigDecimal getPrecio() {
        return precio;
    }

    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Ventas ventas = (Ventas) o;
        return id == ventas.id && Objects.equals(nombreProducto, ventas.nombreProducto) && Objects.equals(fecha, ventas.fecha) && Objects.equals(precio, ventas.precio) && Objects.equals(ventasProductos, ventas.ventasProductos);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nombreProducto, fecha, precio, ventasProductos);
    }
}
