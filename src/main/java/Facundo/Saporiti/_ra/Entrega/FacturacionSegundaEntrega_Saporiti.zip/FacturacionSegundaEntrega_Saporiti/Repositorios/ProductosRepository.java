package Facundo.Saporiti._ra.Entrega.FacturacionSegundaEntrega_Saporiti.Repositorios;

import Facundo.Saporiti._ra.Entrega.FacturacionSegundaEntrega_Saporiti.Models.Productos;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductosRepository extends JpaRepository<Productos, Integer> {
}
