package Facundo.Saporiti._ra.Entrega.FacturacionSegundaEntrega_Saporiti.Services;

import Facundo.Saporiti._ra.Entrega.FacturacionSegundaEntrega_Saporiti.Models.Ventas;
import Facundo.Saporiti._ra.Entrega.FacturacionSegundaEntrega_Saporiti.Repositorios.VentasRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class VentasService {
    @Autowired
    private VentasRepository ventasRepository;

    public Ventas crearVenta(Ventas ventas) {
        return ventasRepository.save(ventas);
    }

    public Ventas actualizarVenta(Ventas ventas) {
        return ventasRepository.save(ventas);
    }

    public Optional<Ventas> buscarVentaById(Integer idVentas) {
        return ventasRepository.findById(idVentas);
    }

    public void eliminarVenta(Integer idVentas) {
        ventasRepository.deleteById(idVentas);
    }
}