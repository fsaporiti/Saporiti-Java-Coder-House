package Facundo.Saporiti._ra.Entrega.FacturacionSegundaEntrega_Saporiti.Models;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "PRODUCTO")
public class Productos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "NOMBRE")
    private String nombre;

    @Column(name = "MARCA")
    private String marca;

    @Column(name = "PRECIO")
    private BigDecimal precio;

    @Column(name = "STOCK")
    private int stock;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CLIENTE_ID")
    private Cliente cliente;

    @OneToMany(mappedBy = "producto", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Ventas_Productos> ventasProductos;

    public Productos() {
    }

    public Productos(Cliente cliente, String nombre, String marca, BigDecimal precio, int stock) {
        this.cliente = cliente;
        this.nombre = nombre;
        this.marca = marca;
        this.precio = precio;
        this.stock = stock;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public BigDecimal getPrecio() {
        return precio;
    }

    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public List<Ventas_Productos> getVentasProductos() {
        return ventasProductos;
    }

    public void setVentasProductos(List<Ventas_Productos> ventasProductos) {
        this.ventasProductos = ventasProductos;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Productos productos = (Productos) o;
        return id == productos.id && stock == productos.stock && Objects.equals(nombre, productos.nombre) && Objects.equals(marca, productos.marca) && Objects.equals(precio, productos.precio) && Objects.equals(ventasProductos, productos.ventasProductos);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nombre, marca, precio, stock, ventasProductos);
    }
}
