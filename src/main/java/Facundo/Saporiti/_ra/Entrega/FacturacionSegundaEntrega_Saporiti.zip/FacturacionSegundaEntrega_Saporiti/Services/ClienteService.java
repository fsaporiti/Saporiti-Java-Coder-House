package Facundo.Saporiti._ra.Entrega.FacturacionSegundaEntrega_Saporiti.Services;

import Facundo.Saporiti._ra.Entrega.FacturacionSegundaEntrega_Saporiti.Models.Cliente;
import Facundo.Saporiti._ra.Entrega.FacturacionSegundaEntrega_Saporiti.Repositorios.ClienteRepository;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service

public class ClienteService {
    @Autowired
    private ClienteRepository clienteRepository;

    public Cliente crearCliente(Cliente cliente) {
        return clienteRepository.save(cliente);
    }

    public Cliente actualizarCliente(Cliente cliente) {
        return clienteRepository.save(cliente);
    }

    public Optional<Cliente> buscarClienteById(Integer idCliente) {
        return clienteRepository.findById(idCliente);
    }

    public void eliminarCliente(Integer idCliente) {
        clienteRepository.deleteById(idCliente);
    }
}

//    public void update (Object obj){
//        Session session = sessionFactory.getCurrentSession();
//        session.beginTransaction();
//        session.saveOrUpdate(obj);
//        session.getTransaction().commit();
//    }